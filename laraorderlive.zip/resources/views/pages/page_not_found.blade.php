<!DOCTYPE html>
<html lang="en">

<head>
  @include('partials._stylesheets')
</head>

<body>
    <div class="login-body">
       <img src="resources/images/back.jpg">
    </div>
    <div class="not_found">
        
    <h3>Page Not Found</h3>
    <p>Error 404</p>
    </div>
    

</body>
</html>